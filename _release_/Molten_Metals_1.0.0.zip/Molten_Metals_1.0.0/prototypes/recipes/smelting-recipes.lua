require("prototypes.recipes.recipe-util")

make_new_smelting_recipe( "iron-ore", {2,2}, {40,40}, {3.2,3.2})
make_new_smelting_recipe( "copper-ore", {2,2}, {40,40}, {3.2,3.2})
make_new_smelting_recipe( "stone", {2,2}, {40,40}, {3.2,3.2})
make_new_smelting_recipe( "uranium-ore", {2,2}, {40,40}, {3.2,3.2})

