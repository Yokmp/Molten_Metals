data:extend(
{
  {
    type = "recipe-category",
    name = "ymm_smelting"
  },
  {
    type = "recipe-category",
    name = "ymm_casting"
  },
})
