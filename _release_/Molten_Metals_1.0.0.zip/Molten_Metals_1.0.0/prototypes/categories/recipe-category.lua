data:extend(
{
  {
    type = "recipe-category",
    name = "Y_smelting"
  },
  {
    type = "recipe-category",
    name = "Y_casting"
  },
  --[[
  {
    type = "item-subgroup",
    name = "intermediate",
    group = "molten-metal",
    order = "a",
  },]]--
})
