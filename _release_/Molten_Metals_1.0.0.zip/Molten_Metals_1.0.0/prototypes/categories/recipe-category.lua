data:extend(
{
  {
    type = "recipe-category",
    name = "ymm_smelting"
  },
  {
    type = "recipe-category",
    name = "ymm_casting"
  },
  --[[
  {
    type = "item-subgroup",
    name = "intermediate",
    group = "molten-metal",
    order = "a",
  },]]--
})
