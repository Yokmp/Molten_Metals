data:extend({
  {
      type = "bool-setting",
      name = "ymm-allow-barreling",
      setting_type = "startup",
      default_value = false
  },
  {
      type = "bool-setting",
      name = "ymm-enable-slag",
      setting_type = "startup",
      default_value = true
  },
})