# A small Mod for Factorio built around Scrap.

This README is a stub!<br />


This Mod is written under Factorio 1.1.33.
It inserts its data in the data-updates stage.
Affected are only "vanilla-names" (iron, copper, steel). If you want to add scrap for 
other mods recipes then just edit data-updates.lua where youll find the two array at the top of the file.

## Updates
* Initial release

## Known Issues
* None yet

## Languages
* english
* deutsch

## ToDo
* [ ] recipe and Tech-Cost Balancing
* [ ] better Icons
* [ ] Techtree overhaul (maybe)
* [ ] Options/Settings
* [ ] Interface
* [ ] Additional recipes (maybe)

## How to contribute?

Please use the Issues Tab and share your suggestions and/or code.
