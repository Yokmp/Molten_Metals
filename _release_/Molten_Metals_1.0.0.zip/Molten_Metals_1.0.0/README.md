# A small Factorio mod which adds molten ores.

This Mod is written under Factorio 1.1.33.
It inserts its data in the data stage.
Affected are only "vanilla-ores" (iron and copper). If you want to add ores from 
other mods just edit data.lua where you'll find the two arrays at the top of the file.

## Updates
* Initial release

## Known Issues
* None yet

## Languages
* english
* deutsch

## ToDo
* [ ] Balancing
* [ ] better Icons
* [ ] Techtree adjustments (maybe)
* [ ] Options/Settings
* [ ] Interface
* [ ] Additional recipes (maybe)

## How to contribute?

Please use the Issues Tab and share your suggestions and/or code.
