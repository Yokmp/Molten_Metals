
-- require("prototypes.categories.recipe-category")
-- require("prototypes.item.machines")
-- require("prototypes.entity.entities")
-- require("prototypes.recipes.machines")

-- -- require("prototypes.type-fluids")
-- -- require("prototypes.ore-to-fluid")
-- -- require("prototypes.fluid-to-item")

-- require("prototypes.item.slag")
-- require("prototypes.recipes.slag")


-- require("prototypes.item.fluids")
-- require("prototypes.recipes.copper")
-- require("prototypes.recipes.iron")
-- require("prototypes.recipes.stone")
-- require("prototypes.recipes.uranium")
-- require("prototypes.recipes.recipes")

-- require("prototypes.technology.molten-metals")

