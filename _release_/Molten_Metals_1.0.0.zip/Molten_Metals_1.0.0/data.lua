

-- log(serpent.block(data.raw["assembling-machine"]["assembling-machine-2"]))

-- assert(1==2)

require("functions")

require("prototypes.categories.recipe-category")

require("prototypes.item.slag")
require("prototypes.item.fluids")
require("prototypes.item.machines")

require("prototypes.entity.entities")

require("prototypes.recipes.copper")
require("prototypes.recipes.iron")
require("prototypes.recipes.machines")
require("prototypes.recipes.recipes")
require("prototypes.recipes.slag")

require("prototypes.technology.molten-metals")